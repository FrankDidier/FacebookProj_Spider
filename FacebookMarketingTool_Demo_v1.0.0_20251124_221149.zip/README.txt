╔════════════════════════════════════════════════════════════════╗
║         Facebook Marketing Tool - Client Instructions         ║
╚════════════════════════════════════════════════════════════════╝

QUICK START:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

macOS Users:
  1. Double-click "FacebookMarketingTool.app"
  2. If macOS warns about security:
     - Right-click the app → "Open" (first time only)
     - Or run: xattr -cr FacebookMarketingTool.app
  3. The application will start automatically

Windows Users:
  1. Double-click "FacebookMarketingTool.exe"
  2. If Windows warns about security:
     - Click "More info" → "Run anyway" (first time only)
  3. The application will start automatically

Linux Users:
  1. Open terminal in this folder
  2. Run: chmod +x FacebookMarketingTool
  3. Run: ./FacebookMarketingTool

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

FEATURES INCLUDED:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Facebook Features:
  • FB Group Specified Collection
  • FB Group Member Rapid Collection
  • FB Group Post Collection
  • FB Public Page Collection
  • Plus all original features

Instagram Features:
  • Instagram Follower Collection
  • Instagram Following Collection
  • Instagram Profile Collection
  • Instagram Reels Comment Collection

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CONFIGURATION:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

You can modify "config.ini" to customize settings:
  • Account numbers
  • Thread counts
  • Target users/keywords
  • Data storage paths

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TROUBLESHOOTING:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

macOS: "App is damaged"
  → Run: xattr -cr FacebookMarketingTool.app

Windows: "Windows protected your PC"
  → Right-click → Properties → Unblock
  → Or: Right-click → Run as administrator

App won't start:
  → Make sure you have extracted all files
  → Check that config.ini is in the same folder
  → Try running from terminal/command prompt for error messages

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SUPPORT:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For support or questions, please contact your provider.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Version: 1.0.0
Build Date: $(date +"%Y-%m-%d")
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
